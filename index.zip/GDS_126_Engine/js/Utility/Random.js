//Returns a random number between a range of numbers from low to high
function rand(low=0, high=1)
{
		return Math.random() * (high - low) + low;
}


